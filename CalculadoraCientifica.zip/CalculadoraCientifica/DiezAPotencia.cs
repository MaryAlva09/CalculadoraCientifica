﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculadoraCientifica
{
    class DiezAPotencia
    {
        public double Calcular(double x)
        {
            return Math.Pow(10, x);
        }
    }
}
