﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculadoraCientifica
{
    class LogaritmoNatural
    {
        public double Calcular(double x)
        {
            return Math.Log(x);
        }
    }
}
