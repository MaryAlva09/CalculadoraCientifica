﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculadoraCientifica
{
    class Modulo
    {
        public double Calcular(double x, double y)
        {
            return x % y;
        }
    }
}
